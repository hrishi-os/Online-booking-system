
<?php
  

    include "header.php";

    function city()
    {
        include "dbcon.php";
        $se=mysqli_query($con,"select *from city");
        while($se1=mysqli_fetch_assoc($se))
        {
            echo "<option>".$se1['name']."</option>";
        }
    }
    function station()
    {
        include "dbcon.php";
        $se=mysqli_query($con,"select *from station");
        while($se1=mysqli_fetch_assoc($se))
        {
            echo "<option>".$se1['name']."</option>";
        }
    }
?>


<div class="row">
<div class="col-md-12 px-0">
<!-- Carousel -->
<div id="demo" class="carousel slide" data-bs-ride="carousel">

  <!-- Indicators/dots -->
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#demo" data-bs-slide-to="0" class="active"></button>
    <button type="button" data-bs-target="#demo" data-bs-slide-to="1"></button>
    <button type="button" data-bs-target="#demo" data-bs-slide-to="2"></button>
  </div>
  
  <!-- The slideshow/carousel -->
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="img/1.jpg" class="d-block" style="width:100%">
    </div>
    <div class="carousel-item">
      <img src="img/2.png" class="d-block" style="width:100%">
    </div>
  </div>
  
  <!-- Left and right controls/icons -->
  <button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
    <span class="carousel-control-next-icon"></span>
  </button>
</div>
</div>
</div>


<div class="row bg-warning" style="padding: 50px 0px 0px 0px;">
  <div class="col-md-12">
    <div class="container mt-3">
  <h2 align="center">Book Your Ticket</h2><hr>
  <br>
  <!-- Nav tabs -->
  <ul class="nav nav-tabs" role="tablist">
    <li class="nav-item">
      <a class="nav-link active" data-bs-toggle="tab" href="#home"><i class="fa fa-plane"></i> Flights</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" data-bs-toggle="tab" href="#menu1"><i class="fa fa-train"></i> Train</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" data-bs-toggle="tab" href="#menu2"><i class="fa fa-bus"></i> Bus</a>
    </li>
  </ul>

  <!-- Tab panes -->
  <div class="tab-content">
    <div id="home" class="container tab-pane active"><br>
      <h3>Search Flights</h3>
      <p>Enjoy hassle free bookings with BookMyTick</p>
      <form method="post" action="search-result.php">
        <div class="row">
          <div class="col-md-3 mb-3">
            <div class="input-group">
              <span class="input-group-text"><img src="img/up.png" style="height: 20px;"></span>
              <select class="form-control" name="t1">
                <option>Where From?</option>
                <?php city(); ?>
              </select>
            </div>
          </div>
          <div class="col-md-3 mb-3">
            <div class="input-group">
              <span class="input-group-text"><img src="img/down.png" style="height: 20px;"></span>
              <select class="form-control" name="t2">
                <option>Where To?</option>
                <?php city(); ?>
              </select>
            </div>
          </div>
          <div class="col-md-3 mb-3">
            <div class="input-group">
              <span class="input-group-text"><i class="fa fa-check"></i></span>
              <select class="form-control" name="t3">
                <option>Economy</option>
                <option>Business Class</option>
                <option>First Class</option>
                <option>Premium Economy</option>
              </select>
            </div>
          </div>
          <div class="col-md-2 mb-3">
            <div class="input-group">
              <span class="input-group-text"><i class="fa fa-calendar" style="font-size:20px"></i></span>
              <input type="text" placeholder="Date" id="txtDate" class="form-control" name="t4" onfocus="type='date'">
            </div>
          </div>
          <div class="col-md-1 mb-3">
            <input type="submit" name="flight" class="btn btn-info" value="Search">
          </div>
        </div>
      </form>
    </div>
    <div id="menu1" class="container tab-pane fade"><br>
      <form method="post" action="search-result.php">
        <div class="row">
          <div class="col-md-3 mb-3">
            <div class="input-group">
              <span class="input-group-text"><i class="fa fa-location-arrow"></i></span>
              <select class="form-control" name="t1">
                <option>From?</option>
                <?php station(); ?>
              </select>
            </div>
          </div>
          <div class="col-md-3 mb-3">
            <div class="input-group">
              <span class="input-group-text"><i class="fa fa-map-marker"></i></span>
              <select class="form-control" name="t2">
                <option>To?</option>
                <?php station(); ?>
              </select>
            </div>
          </div>
          <div class="col-md-3 mb-3">
            <div class="input-group">
              <span class="input-group-text"><i class="fa fa-calendar"></i></span>
              <input type="text" placeholder="Date" id="txtDate1" name="t3" class="form-control" onfocus="type='date'">
            </div>
          </div>
          <div class="col-md-2 mb-3">
            <div class="input-group">
              <span class="input-group-text"><i class="fa fa-briefcase"></i></span>
              <select class="form-control" name="t4">
                <option>General</option>
                <option>Ladies</option>
                <option>Lower Berth/Sr. Citizen</option>
                <option>Person with Disability</option>
                <option>Tatkal</option>
                <option>Premium Tatkal</option>
              </select>
            </div>
          </div>
          <div class="col-md-1 mb-3">
            <input type="submit" name="train" class="btn btn-info" value="Search">
          </div>
        </div>
      </form>
    </div>
    <div id="menu2" class="container tab-pane fade"><br>
      <h3>Search Bus</h3>
      <p>Enjoy hassle free bookings with BookMyTick</p>
      <form method="post" action="search-result.php">
        <div class="row">
          <div class="col-md-4 mb-3">
            <div class="input-group">
              <span class="input-group-text"><i class="fa fa-bus"></i></span>
              <select class="form-control" name="t1">
                <option>Where From?</option>
                <?php city(); ?>
              </select>
            </div>
          </div>
          <div class="col-md-4 mb-3">
            <div class="input-group">
              <span class="input-group-text"><i class="fa fa-bus"></i></span>
              <select class="form-control" name="t2">
                <option>Where To?</option>
                <?php city(); ?>
              </select>
            </div>
          </div>
          <div class="col-md-3 mb-3">
            <div class="input-group">
              <span class="input-group-text"><i class="fa fa-calendar" style="font-size:20px"></i></span>
              <input type="text" placeholder="Onward Date" id="txtDate2" class="form-control" name="t4" onfocus="type='date'">
            </div>
          </div>
          <div class="col-md-1 mb-3">
            <input type="submit" name="bus" class="btn btn-info" value="Search">
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
  </div>
</div>





<div class="row" style="padding: 50px 0px 0px 0px;">
  <div class="col-md-12"><h2>Popular Destinations</h2></div>
</div>
<div class="row" style="padding: 0px 0px 50px 0px;">

    <div class="col-md-3">
      <div class="card">
        <img src="img/delhi.webp" class="card-top-img">
        <div class="card-body">
          <h1 align="center"><i class="fa fa-map-marker text-info"></i> Delhi</h1>
        </div>
      </div>
    </div>

    <div class="col-md-3">
      <div class="card">
        <img src="img/goa.jpeg" class="card-top-img">
        <div class="card-body">
          <h1 align="center"><i class="fa fa-map-marker text-info"></i> Goa</h1>
        </div>
      </div>
    </div>

    <div class="col-md-3">
      <div class="card">
        <img src="img/mumbai.webp" class="card-top-img">
        <div class="card-body">
          <h1 align="center"><i class="fa fa-map-marker text-info"></i> Mumbai</h1>
        </div>
      </div>
    </div>

    <div class="col-md-3">
      <div class="card">
        <img src="img/jaipur.jpeg" class="card-top-img">
        <div class="card-body">
          <h1 align="center"><i class="fa fa-map-marker text-info"></i> Jaipur</h1>
        </div>
      </div>
    </div>

</div>


<div class="row" style="padding: 50px 0px 50px 0px;">
  <div class="col-md-4" align="center">
    <div class="mt-4 p-5 bg-primary text-white rounded">
      <div class="row">
        <div class="col-md-3">
          <h1><i class="fa fa-facebook" style="font-size:50px"></i></h1>
        </div>
        <div class="col-md-9">
          <h4>Connect with us<br>on Facebook</h4>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-4" align="center">
    <div class="mt-4 p-5 bg-danger text-white rounded">
      <div class="row">
        <div class="col-md-3">
          <h1><i class="fa fa-twitter" style="font-size:50px"></i></h1>
        </div>
        <div class="col-md-9">
          <h4>Follow us<br>on Twitter</h4>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-4" align="center">
    <div class="mt-4 p-5 bg-success text-white rounded">
      <div class="row">
        <div class="col-md-3">
          <h1><i class="fa fa-linkedin" style="font-size:50px"></i></h1>
        </div>
        <div class="col-md-9">
          <h4>Stay connected<br>on Linked In</h4>
        </div>
      </div>
    </div>
  </div>
</div>


<div class="row" style="padding: 50px 0px 0px 0px;">
  <div class="col-md-12 bg-info text-white">
    <h4 align="center">&copy; 2023 BookMyTick. All rights reserved.</h4>
  </div>
</div>
</body>
</html>



