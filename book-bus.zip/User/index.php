<?php
session_start();
if(isset($_SESSION['ulog']))
{
 include 'header.php'; 
 include '../dbcon.php';
$em=$_SESSION['ulog'];
$se=mysqli_query($con,"select *from users where email='$em'");
$se1=mysqli_fetch_assoc($se);
?>

<div class="row">
	<div class="col-md-6 offset-md-3" style="padding:30px 0px 30px 0px">
		<div class="card" style="box-shadow: 0px 0px 10px #000;">
			<div class="card-header bg-info">
				<h4>My Profile</h4>
			</div>
			<div class="card-body">
				<table class="table table-hover table-striped">
					<tr>
						<th>Name</th>
						<td><?php echo $se1['name']; ?></td>
					</tr>
					<tr>
						<th>Email</th>
						<td><?php echo $se1['email']; ?></td>
					</tr>
					<tr>
						<th>Mobile No.</th>
						<td><?php echo $se1['mobile']; ?></td>
					</tr>
					<tr>
						<th>Gender</th>
						<td><?php echo $se1['gender']; ?></td>
					</tr>
					<tr>
						<th>Date of Registration</th>
						<td><?php echo $se1['dor']; ?></td>
					</tr>
				</table>
			</div>
		</div>
	</div>
</div>

<?php
}
else
{
	header("location:../index.php");
}
?>