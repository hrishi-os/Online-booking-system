<?php
session_start();
if(isset($_SESSION['ulog']))
{
 include 'header.php'; 
 include '../dbcon.php';
$em=$_SESSION['ulog'];
$se=mysqli_query($con,"select *from users where email='$em'");
$se1=mysqli_fetch_assoc($se);
$ps=$se1['password'];
if(isset($_POST['change']))
{
	$a=$_POST['t1'];
	$b=$_POST['t2'];
	$c=$_POST['t3'];
	if($ps==$a)
	{
		if($b==$c)
		{
			$in=mysqli_query($con,"update users set password='$c' where email='$em'");
			if($in)
			{
				echo "<script>alert('Password changed successfully...!');</script>";
				echo "<script>window.location='logout.php';</script>";
			}
		}
		else
		{
			echo "<script>alert('New password and Confirm Password mismatch...!');</script>";
		}
	}
	else
	{
		echo "<script>alert('Current password mismatch...!');</script>";
	}
}
?>

<div class="row">
	<div class="col-md-4 offset-md-4" style="padding:30px 0px 30px 0px">
		<div class="card" style="box-shadow: 0px 0px 10px #000;">
			<div class="card-header bg-info">
				<h4>Change Password</h4>
			</div>
			<div class="card-body">
				<form method="post">
					<label><strong>Current Password</strong></label>
					<input type="text" name="t1" class="form-control" placeholder="Enter Your Current Password *" required>
					<label><strong>New Password</strong></label>
					<input type="password" name="t2" class="form-control" placeholder="Enter Your New Password *" required>
					<label><strong>Confirm New Password</strong></label>
					<input type="text" name="t3" class="form-control" placeholder="Enter Your Confirm New Password *" required>
					<br>
					<input type="submit" name="change" class="btn btn-warning" value="Change Password">
				</form>
			</div>
		</div>
	</div>
</div>

<?php
}
else
{
	header("location:../index.php");
}
?>