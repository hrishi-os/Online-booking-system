<?php
session_start();
if(isset($_SESSION['ulog']))
{
 include 'header.php'; 
 include '../dbcon.php';
$em=$_SESSION['ulog'];
$se=mysqli_query($con,"select *from users where email='$em'");
$se1=mysqli_fetch_assoc($se);

$tr=mysqli_query($con,"select *from booking_train where uid='$em'");
$fl=mysqli_query($con,"select *from booking where uid='$em'");
$bs=mysqli_query($con,"select *from booking_bus where uid='$em'");

if(isset($_GET['tcid']))
{
	$tcid=$_GET['tcid'];
	$up=mysqli_query($con,"update booking_train set status='Cancelled' where id=$tcid");
	if($up)
	{
		echo "<script>alert('Cancelled Successfully...!');</script>";
		echo "<script>window.location='booking-history.php';</script>";
	}
}
if(isset($_GET['bcid']))
{
	$bcid=$_GET['bcid'];
	$up=mysqli_query($con,"update booking_bus set status='Cancelled' where id=$bcid");
	if($up)
	{
		echo "<script>alert('Cancelled Successfully...!');</script>";
		echo "<script>window.location='booking-history.php';</script>";
	}
}
if(isset($_GET['fcid']))
{
	$fcid=$_GET['fcid'];
	$up=mysqli_query($con,"update booking set status='Cancelled' where id=$fcid");
	if($up)
	{
		echo "<script>alert('Cancelled Successfully...!');</script>";
		echo "<script>window.location='booking-history.php';</script>";
	}
}
?>

<div class="row">
	<div class="col-md-10 offset-md-1" style="padding:30px 0px 30px 0px">
		<div class="card" style="box-shadow: 0px 0px 10px #000;">
			<div class="card-header bg-info">
				<h4>Traing Booking Details</h4>
			</div>
			<div class="card-body">
				<table class="table table-hover table-striped">
					<tr>
						<th>Train No.</th>
						<th>Source</th>
						<th>Destination</th>
						<th>Fare</th>
						<th>Quantity</th>
						<th>Total Amount (with GST)</th>
						<th>Journey Date</th>
						<th>Book Date</th>
						<th>Status</th>
						<th>Action</th>
					</tr>
					<?php while($tr1=mysqli_fetch_assoc($tr))
					{
						$id=$tr1['trainid'];
						$tr2=mysqli_query($con,"select *from train where id=$id");
						$tr3=mysqli_fetch_assoc($tr2);
						?>
						<tr>
							<td><?php echo $tr3['trainno']; ?></td>	
							<td><?php echo $tr3['source']; ?></td>	
							<td><?php echo $tr3['destination']; ?></td>	
							<td><?php echo $tr3['fare']; ?>/-</td>	
							<td><?php echo $tr1['quantity']; ?></td>	
							<td><?php echo round($tr3['fare']*$tr1['quantity']*18/100)+$tr3['fare']; ?>/-</td>	
							<td><?php echo $tr1['jdate']; ?></td>
							<td><?php echo $tr1['dob']; ?></td>
							<td><?php echo $tr1['status']; ?></td>
							<td><a href="booking-history.php?tcid=<?php echo $tr1['id']; ?>" class="btn btn-warning btn-sm">Cancel</a></td>
						</tr>
						<?php
					} ?>
				</table>
			</div>
		</div>
	</div>
	<div class="col-md-10 offset-md-1" style="padding:30px 0px 30px 0px">
		<div class="card" style="box-shadow: 0px 0px 10px #000;">
			<div class="card-header bg-info">
				<h4>Flight Booking Details</h4>
			</div>
			<div class="card-body">
				<table class="table table-hover table-striped">
					<tr>
						<th>Source</th>
						<th>Destination</th>
						<th>Fare</th>
						<th>Quantity</th>
						<th>Total Amount (with GST)</th>
						<th>Journey Date</th>
						<th>Book Date</th>
						<th>Status</th>
						<th>Action</th>
					</tr>
					<?php while($fl1=mysqli_fetch_assoc($fl))
					{
						$fid=$fl1['fareid'];
						$fl2=mysqli_query($con,"select *from fare where id=$fid");
						$fl3=mysqli_fetch_assoc($fl2);
						?>
						<tr>	
							<td><?php echo $fl3['source']; ?></td>	
							<td><?php echo $fl3['destination']; ?></td>	
							<td><?php echo $fl3['fare']; ?>/-</td>	
							<td><?php echo $fl1['quantity']; ?></td>	
							<td><?php echo round($fl3['fare']*$fl1['quantity']*18/100)+$fl3['fare']; ?>/-</td>	
							<td><?php echo $fl1['jdate']; ?></td>
							<td><?php echo $fl1['dob']; ?></td>
							<td><?php echo $fl1['status']; ?></td>
							<td><a href="booking-history.php?fcid=<?php echo $fl1['id']; ?>" class="btn btn-warning btn-sm">Cancel</a></td>
						</tr>
						<?php
					} ?>
				</table>
			</div>
		</div>
	</div>
	<div class="col-md-10 offset-md-1" style="padding:30px 0px 30px 0px">
		<div class="card" style="box-shadow: 0px 0px 10px #000;">
			<div class="card-header bg-info">
				<h4>Bus Booking Details</h4>
			</div>
			<div class="card-body">
				<table class="table table-hover table-striped">
					<tr>
						<th>Bus Name</th>
						<th>Source</th>
						<th>Destination</th>
						<th>Fare</th>
						<th>Quantity</th>
						<th>Total Amount (with GST)</th>
						<th>Journey Date</th>
						<th>Book Date</th>
						<th>Status</th>
						<th>Action</th>
					</tr>
					<?php while($bs1=mysqli_fetch_assoc($bs))
					{
						$bfid=$bs1['bfid'];
						$bs2=mysqli_query($con,"select *from bus_fare where id=$bfid");
						$bs3=mysqli_fetch_assoc($bs2);
						?>
						<tr>
							<td><?php echo $bs3['busname']; ?></td>	
							<td><?php echo $bs3['source']; ?></td>	
							<td><?php echo $bs3['destination']; ?></td>	
							<td><?php echo $bs3['fare']; ?>/-</td>	
							<td><?php echo $bs1['quantity']; ?></td>	
							<td><?php echo round($tr3['fare']*$bs1['quantity']*18/100)+$bs3['fare']; ?>/-</td>	
							<td><?php echo $bs1['jdate']; ?></td>
							<td><?php echo $bs1['dob']; ?></td>
							<td><?php echo $bs1['status']; ?></td>
							<td><a href="booking-history.php?bcid=<?php echo $bs1['id']; ?>" class="btn btn-warning btn-sm">Cancel</a></td>
						</tr>
						<?php
					} ?>
				</table>
			</div>
		</div>
	</div>
</div>

<?php
}
else
{
	header("location:../index.php");
}
?>