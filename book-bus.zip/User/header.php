<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
	<title>User Dashboard</title>
	<style type="text/css">
		body {
    background: linear-gradient(#b5e48c, #457b9d) fixed;
}
	</style>
</head>
<body class="container-fluid">
	<div class="row bg-primary">
		<div class="col-md-12">
			<nav class="navbar navbar-expand-sm bg-primary navbar-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php"><img src="../img/logo.png"></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="booking-history.php">Booking History</a>
        </li>
        <li class="nav-item dropdown">
  <a class="nav-link dropdown-toggle text-dark" href="#" role="button" data-bs-toggle="dropdown"><strong><?php echo $_SESSION['name']; ?></strong></a>
  <ul class="dropdown-menu">
    <li><a class="dropdown-item" href="index.php">My Profile</a></li>
    <li><a class="dropdown-item" href="change-password.php">Change Password</a></li>
    <li><a class="dropdown-item" href="logout.php">Logout</a></li>
  </ul>
</li>   
      </ul>
    </div>
  </div>
</nav>
		</div>
	</div>
</body>
</html>