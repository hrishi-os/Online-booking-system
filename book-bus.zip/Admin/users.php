 <?php
session_start();
if(isset($_SESSION['alog']))
{
    include "header.php";
    include "../dbcon.php";
    $bo=mysqli_query($con,"select *from users");

    if(isset($_GET['id']))
    {
        $id=$_GET['id'];
        $de=mysqli_query($con,"delete from users where id=$id");
        if($de)
        {
            echo "<script>alert('Delete Successfully...!');</script>";
            echo "<script>window.location='users.php';</script>";
        }
    }
?>
<!-- Begin Page Content -->
                <div class="container-fluid">

                   

                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header bg-info">
                                    <h3 class="text-white">Registered Users Details</h3>
                                </div>
                                <div class="card-body">
                                    <table class="table table-hover table-striped">
                                        <tr>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Mobile No.</th>
                                            <th>Gender</th>
                                            <th>Date of Registration</th>
                                            <th>Action</th>
                                        </tr>
                                        <?php while($ma1=mysqli_fetch_assoc($bo))
                                        {
                                            ?>
                                            <tr>
                                                <td><?php echo $ma1['name']; ?></td>
                                                <td><?php echo $ma1['email']; ?></td>
                                                <td><?php echo $ma1['mobile']; ?></td>
                                                <td><?php echo $ma1['gender']; ?></td>
                                                <td><?php echo $ma1['dor']; ?></td>
                                                <td>
                                                    <a class="btn btn-danger btn-sm" href="users.php?id=<?php echo $ma1['id']; ?>"><i class="fa fas fa-trash"></i></a>
                                                </td>
                                            </tr>
                                            <?php
                                        } ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

                <?php
                include "footer.php";
            }
            else
            {
                header("location:../admin-login.html");
            }
            ?>