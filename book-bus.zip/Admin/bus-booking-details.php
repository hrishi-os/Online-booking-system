 <?php
session_start();
if(isset($_SESSION['alog']))
{
    include "header.php";
    include "../dbcon.php";
    $id=$_GET['id'];
    $bo=mysqli_query($con,"select *from booking_bus where id=$id");
    $ma1=mysqli_fetch_assoc($bo);
    $us=$ma1['uid'];
    $us1=mysqli_query($con,"select *from users where email='$us'");
    $us2=mysqli_fetch_assoc($us1);
    $fid=$ma1['bfid'];
    $fid1=mysqli_query($con,"select *from bus_fare where id=$fid");
    $fid2=mysqli_fetch_assoc($fid1);
?>
<!-- Begin Page Content -->
                <div class="container-fluid">

                   

                    <div class="row">
                        <div class="col-md-6 offset-md-3">
                            <div class="card">
                                <div class="card-header bg-info">
                                    <h3 class="text-white">Flight Booking Details</h3>
                                </div>
                                <div class="card-body">
                                    <table class="table table-hover table-striped">
                                        <tr>
                                            <th>Name</th>
                                            <td><?php echo $us2['name']; ?></td>
                                        </tr>
                                        <tr>
                                            <th>Email</th>
                                            <td><?php echo $us2['email']; ?></td>
                                        </tr>
                                        <tr>
                                            <th>Mobile No.</th>
                                            <td><?php echo $us2['mobile']; ?></td>
                                        </tr>
                                        <tr>
                                            <th>Location</th>
                                            <td><?php echo $fid2['source']; ?> To <?php echo $fid2['destination']; ?></td>
                                        </tr>
                                        <tr>
                                            <th>Class</th>
                                            <td><?php echo $fid2['cl']; ?></td>
                                        </tr>
                                        <tr>
                                            <th>Bus Name</th>
                                            <td><?php echo $fid2['busname']; ?></td>
                                        </tr>
                                        <tr>
                                            <th>Date</th>
                                            <td><?php echo $ma1['jdate']; ?></td>
                                        </tr>
                                        <tr>
                                            <th>Date of Booking</th>
                                            <td><?php echo $ma1['dob']; ?></td>
                                        </tr>
                                        <tr>
                                            <th>No of Person</th>
                                            <td><?php echo $qt=$ma1['quantity']; ?></td>
                                        </tr>
                                        <tr>
                                            <th>Fare</th>
                                            <td><?php echo $fr=$fid2['fare']; ?>/-</td>
                                        </tr>
                                        <tr>
                                            <th>Total Amount</th>
                                            <td><?php echo $tm=$qt*$fr; ?>/-</td>
                                        </tr>
                                        <tr>
                                            <th>Tax (18%) GST</th>
                                            <td><?php echo $tx=round(($tm*18)/100); ?>/-</td>
                                        </tr>
                                        <tr>
                                            <th>Payble Amount</th>
                                            <th><?php echo $tx+$tm; ?>/-</th>
                                        </tr>
                                       
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

                <?php
                include "footer.php";
            }
            else
            {
                header("location:../admin-login.html");
            }
            ?>