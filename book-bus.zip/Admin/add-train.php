 <?php
session_start();
if(isset($_SESSION['alog']))
{
    include "header.php";
    include "../dbcon.php";
    if(isset($_POST['send']))
    {
        $a=$_POST['t1'];
        $b=$_POST['t2'];
        $c=$_POST['t3'];
        $d=$_POST['t4'];
        $e=$_POST['t5'];
        $time=$_POST['time'];
        $in=mysqli_query($con,"insert into train(source,destination,trainno,timing,cl,fare) values('$a','$b','$c','$time','$d','$e')");
        if($in)
        {
            echo "<script>alert('Add Successfully...');</script>";
            echo "<script>window.location='add-train.php';</script>";
        }
    }
    function station()
    {
        include "../dbcon.php";
        $se=mysqli_query($con,"select *from station");
        while($se1=mysqli_fetch_assoc($se))
        {
            echo "<option>".$se1['name']."</option>";
        }
    }

    if(isset($_GET['did']))
    {
        $did=$_GET['did'];
        $de=mysqli_query($con,"delete from train where id=$did");
        if($de)
        {
            echo "<script>alert('Delete Successfully...');</script>";
            echo "<script>window.location='add-train.php';</script>";
        }
    }

    $ma=mysqli_query($con,"select *from train");
?>
<!-- Begin Page Content -->
                <div class="container-fluid">

                   

                    <div class="row">
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-header bg-info">
                                    <h3 class="text-white">Add Train</h3>
                                </div>
                                <div class="card-body">
                                    <form method="post">
                                        <label><strong>Source</strong></label>
                                        <select class="form-control" name="t1">
                                            <?php station(); ?>
                                        </select>
                                        <label><strong>Destination</strong></label>
                                        <select class="form-control" name="t2">
                                            <?php station(); ?>
                                        </select>
                                        <label><strong>Train No.</strong></label>
                                        <input type="text" name="t3" class="form-control" required placeholder="Train No.">
                                        <label><strong>Timing</strong></label>
                                        <input type="text" name="time" class="form-control" required placeholder="Train Timing">
                                        <label><strong>Class</strong></label>
                                        <select class="form-control" name="t4">
                                            <option>General</option>
                                            <option>Ladies</option>
                                            <option>Lower Berth/Sr. Citizen</option>
                                            <option>Person with Disability</option>
                                            <option>Tatkal</option>
                                            <option>Premium Tatkal</option>
                                        </select>
                                        <label><strong>Fare (in Rs.)</strong></label>
                                        <input type="text" name="t5" class="form-control" placeholder="e.g. 1200" required>
                                        <br>
                                        <input type="submit" name="send" class="btn btn-primary btn-block" value="ADD">
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="card">
                                <div class="card-header bg-info">
                                    <h3 class="text-white">Manage Train</h3>
                                </div>
                                <div class="card-body">
                                    <table class="table table-hover table-striped">
                                        <tr>
                                            <th>Source</th>
                                            <th>Destination</th>
                                            <th>Train No</th>
                                            <th>Timing</th>
                                            <th>Class</th>
                                            <th>Fare</th>
                                            <th>Date of Entry</th>
                                            <th>Action</th>
                                        </tr>
                                        <?php while($ma1=mysqli_fetch_assoc($ma))
                                        {
                                            ?>
                                            <tr>
                                                <td><?php echo $ma1['source']; ?></td>
                                                <td><?php echo $ma1['destination']; ?></td>
                                                <td><?php echo $ma1['trainno']; ?></td>
                                                <td><?php echo $ma1['timing']; ?></td>
                                                <td><?php echo $ma1['cl']; ?></td>
                                                <td><?php echo $ma1['fare']; ?>/-</td>
                                                <td><?php echo $ma1['doe']; ?></td>
                                                <td>
                                                    <a href="add-train.php?did=<?php echo $ma1['id']; ?>"><i class="fa fas fa-trash"></i></a>
                                                </td>
                                            </tr>
                                            <?php
                                        } ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

                <?php
                include "footer.php";
            }
            else
            {
                header("location:../admin-login.html");
            }
            ?>