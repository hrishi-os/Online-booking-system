<?php
session_start();
if(isset($_SESSION['alog']))
{
    include "header.php";
    include "../dbcon.php";

    $fl=mysqli_query($con,"select *from fare");
    $fl1=mysqli_num_rows($fl);
    $book=mysqli_query($con,"select *from booking");
    $book1=mysqli_num_rows($book);
    $book2=mysqli_query($con,"select *from booking_train");
    $book3=mysqli_num_rows($book2);
    $book4=mysqli_query($con,"select *from booking_bus");
    $book5=mysqli_num_rows($book4);
    $book6=$book3+$book1+$book5;

    $tr=mysqli_query($con,"select *from train");
    $tr1=mysqli_num_rows($tr);
    $bs=mysqli_query($con,"select *from bus_fare");
    $bs1=mysqli_num_rows($bs);
    
?>
<!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
                    </div>

                    <!-- Content Row -->
                    <div class="row">

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Flight Added</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $fl1; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-plane fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                Train Added</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $tr1; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-train fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Bus Added
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?php echo $bs1; ?></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Pending Requests Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                Total Booking</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $book6; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-comments fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

                <?php
                include "footer.php";
            }
            else
            {
                header("location:../admin-login.html");
            }
            ?>