 <?php
session_start();
if(isset($_SESSION['alog']))
{
    include "header.php";
    include "../dbcon.php";
    if(isset($_POST['send']))
    {
        $a=$_POST['t1'];
        $b=$_POST['t2'];
        $c=$_POST['t3'];
        $d=$_POST['t4'];
        $in=mysqli_query($con,"insert into fare(source,destination,cl,fare) values('$a','$b','$c','$d')");
        if($in)
        {
            echo "<script>alert('Add Successfully...');</script>";
            echo "<script>window.location='add-fare.php';</script>";
        }
    }
    function city()
    {
        include "../dbcon.php";
        $se=mysqli_query($con,"select *from city");
        while($se1=mysqli_fetch_assoc($se))
        {
            echo "<option>".$se1['name']."</option>";
        }
    }

    if(isset($_GET['did']))
    {
        $did=$_GET['did'];
        $de=mysqli_query($con,"delete from fare where id=$did");
        if($de)
        {
            echo "<script>alert('Delete Successfully...');</script>";
            echo "<script>window.location='add-fare.php';</script>";
        }
    }

    $ma=mysqli_query($con,"select *from fare");
?>
<!-- Begin Page Content -->
                <div class="container-fluid">

                   

                    <div class="row">
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-header bg-info">
                                    <h3 class="text-white">Add Fare</h3>
                                </div>
                                <div class="card-body">
                                    <form method="post">
                                        <label><strong>Source</strong></label>
                                        <select class="form-control" name="t1">
                                            <?php city(); ?>
                                        </select>
                                        <label><strong>Destination</strong></label>
                                        <select class="form-control" name="t2">
                                            <?php city(); ?>
                                        </select>
                                        <label><strong>Class</strong></label>
                                        <select class="form-control" name="t3">
                                            <option>Economy</option>
                                            <option>Business Class</option>
                                            <option>First Class</option>
                                            <option>Premium Economy</option>
                                        </select>
                                        <label><strong>Fare (in Rs.)</strong></label>
                                        <input type="text" name="t4" class="form-control" placeholder="e.g. 1200" required>
                                        <br>
                                        <input type="submit" name="send" class="btn btn-primary btn-block" value="ADD">
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="card">
                                <div class="card-header bg-info">
                                    <h3 class="text-white">Manage Fare</h3>
                                </div>
                                <div class="card-body">
                                    <table class="table table-hover table-striped">
                                        <tr>
                                            <th>Source</th>
                                            <th>Destination</th>
                                            <th>Class</th>
                                            <th>Fare</th>
                                            <th>Date of Entry</th>
                                            <th>Action</th>
                                        </tr>
                                        <?php while($ma1=mysqli_fetch_assoc($ma))
                                        {
                                            ?>
                                            <tr>
                                                <td><?php echo $ma1['source']; ?></td>
                                                <td><?php echo $ma1['destination']; ?></td>
                                                <td><?php echo $ma1['cl']; ?></td>
                                                <td><?php echo $ma1['fare']; ?>/-</td>
                                                <td><?php echo $ma1['doe']; ?></td>
                                                <td>
                                                    <a href="add-fare.php?did=<?php echo $ma1['id']; ?>"><i class="fa fas fa-trash"></i></a>
                                                </td>
                                            </tr>
                                            <?php
                                        } ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

                <?php
                include "footer.php";
            }
            else
            {
                header("location:../admin-login.html");
            }
            ?>