 <?php
session_start();
if(isset($_SESSION['alog']))
{
    include "header.php";
    include "../dbcon.php";
    if(isset($_POST['send']))
    {
        $a=$_POST['t1'];
        $in=mysqli_query($con,"insert into city(name) values('$a')");
        if($in)
        {
            echo "<script>alert('Add Successfully...');</script>";
            echo "<script>window.location='add-city.php';</script>";
        }
    }
    $se=mysqli_query($con,"select *from city");

    if(isset($_GET['did']))
    {
        $did=$_GET['did'];
        $de=mysqli_query($con,"delete from city where id=$did");
        if($de)
        {
            echo "<script>alert('Delete Successfully...');</script>";
            echo "<script>window.location='add-city.php';</script>";
        }
    }
?>
<!-- Begin Page Content -->
                <div class="container-fluid">

                   

                    <div class="row">
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-header bg-info">
                                    <h3 class="text-white">Add City</h3>
                                </div>
                                <div class="card-body">
                                    <form method="post">
                                        <label><strong>City</strong></label>
                                        <input type="text" name="t1" class="form-control" placeholder="City Name *" required>
                                        <br>
                                        <input type="submit" name="send" class="btn btn-primary btn-block" value="ADD">
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="card">
                                <div class="card-header bg-info">
                                    <h3 class="text-white">Manage City</h3>
                                </div>
                                <div class="card-body">
                                    <table class="table table-hover table-striped">
                                        <tr>
                                            <th>Name</th>
                                            <th>Date of Entry</th>
                                            <th>Action</th>
                                        </tr>
                                        <?php while($se1=mysqli_fetch_assoc($se))
                                        {
                                            ?>
                                            <tr>
                                                <td><?php echo $se1['name']; ?></td>
                                                <td><?php echo $se1['doe']; ?></td>
                                                <td>
                                                    <a href="add-city.php?did=<?php echo $se1['id']; ?>"><i class="fa fas fa-trash"></i></a>
                                                </td>
                                            </tr>
                                            <?php
                                        } ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

                <?php
                include "footer.php";
            }
            else
            {
                header("location:../admin-login.html");
            }
            ?>