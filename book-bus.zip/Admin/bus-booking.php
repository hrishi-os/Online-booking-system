 <?php
session_start();
if(isset($_SESSION['alog']))
{
    include "header.php";
    include "../dbcon.php";
    $bo=mysqli_query($con,"select *from booking_bus");

    if(isset($_POST['change']))
    {
        $a=$_POST['t1'];
        $b=$_POST['t2'];
        $up=mysqli_query($con,"update booking_bus set status='$b' where id=$a");
        if($up)
        {
            echo "<script>alert('Update Successfully...!');</script>";
            echo "<script>window.location='bus-booking.php';</script>";
        }
    }
?>
<script type="text/javascript">
    function myfun(data)
    {
        var a=data;
        document.forms.f1.t1.value=a;
    }
</script>
<!-- Begin Page Content -->
                <div class="container-fluid">

                   

                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header bg-info">
                                    <h3 class="text-white">Bus Booking Details</h3>
                                </div>
                                <div class="card-body">
                                    <table class="table table-hover table-striped">
                                        <tr>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Mobile No.</th>
                                            <th>Location</th>
                                            <th>Date</th>
                                            <th>Date of Booking</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                        <?php while($ma1=mysqli_fetch_assoc($bo))
                                        {
                                            $us=$ma1['uid'];
                                            $us1=mysqli_query($con,"select *from users where email='$us'");
                                            $us2=mysqli_fetch_assoc($us1);
                                            $fid=$ma1['bfid'];
                                            $fid1=mysqli_query($con,"select *from bus_fare where id=$fid");
                                            $fid2=mysqli_fetch_assoc($fid1);
                                            ?>
                                            <tr>
                                                <td><?php echo $us2['name']; ?></td>
                                                <td><?php echo $us2['email']; ?></td>
                                                <td><?php echo $us2['mobile']; ?></td>
                                                <td><?php echo $fid2['source']; ?> To <?php echo $fid2['destination']; ?></td>
                                                <td><?php echo $ma1['jdate']; ?></td>
                                                <td><?php echo $ma1['dob']; ?></td>
                                                <td><?php echo $ma1['status']; ?></td>
                                                <td>
                                                    <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#myModal" onclick="myfun(<?php echo $ma1['id']; ?>)"><i class="fas fa-edit"></i></button>
                                                    <a class="btn btn-info btn-sm" href="bus-booking-details.php?id=<?php echo $ma1['id']; ?>"><i class="fa fas fa-eye"></i></a>
                                                </td>
                                            </tr>
                                            <?php
                                        } ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->



<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Update Status</h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form method="post" name="f1">
            <label><strong>Select Status</strong></label>
            <input type="hidden" name="t1" id="data">
            <select class="form-control" name="t2">
                <option>Pending</option>
                <option>Confirm</option>
                <option>Cancelled</option>
            </select>
           <br>
           <input type="submit" name="change" value="UPDATE" class="btn btn-warning">
        </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>

                <?php
                include "footer.php";
            }
            else
            {
                header("location:../admin-login.html");
            }
            ?>



