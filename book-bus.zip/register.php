<?php
  

    include "header.php";

    
  if(isset($_POST['send']))
    {
      $a=$_POST['t1'];
      $b=$_POST['t2'];
      $c=$_POST['t3'];
      $d=$_POST['t4'];
      $e=$_POST['t5'];
      $f=$_POST['t6'];
      if($e==$f)
      {
        $in=mysqli_query($con,"insert into users(name,email,mobile,gender,password) values('$a','$b','$c','$d','$e')");
        if($in)
        {
          echo "<script>alert('Registration Succeefully...!');</script>";
          echo "<script>window.location='index.php';</script>";
        }
      }
      else
      {
        echo "<script>alert('Password and Confirm Password mismatch....!');</script>";
      }
    }
      ?>
      <div class="row" style="padding:70px 0px 70px 0px; background: linear-gradient(45deg, #874,#F78);">
        <div class="col-md-8 offset-md-2">
            <div class="card">          
              <div class="card-header bg-primary" align="center">
                <h2 class="text-white">Register Here</h2>
              </div>
              <div class="card-body">
                <form method="post">
                  <div class="row">
                    <div class="col-md-6">
                      <label><strong>Name</strong></label>
                      <input type="text" name="t1" class="form-control" placeholder="Enter Your Name *" required pattern="[A-Za-z ]{3,}">
                    </div>
                    <div class="col-md-6">
                      <label><strong>Email ID</strong></label>
                      <input type="email" name="t2" class="form-control" placeholder="Enter Your Email ID *" required>
                    </div>
                    <div class="col-md-6">
                      <label><strong>Mobile Number</strong></label>
                      <input type="text" name="t3" class="form-control" placeholder="Enter Your Mobile Number *" required pattern="[0-9]{10}">
                    </div>
                    <div class="col-md-6">
                      <label><strong>Gender</strong></label>
                      <select name="t4" class="form-control">
                        <option>Male</option>
                        <option>Female</option>
                        <option>Other</option>
                      </select>
                    </div>
                    <div class="col-md-6">
                      <label><strong>Create Password</strong></label>
                      <input type="password" name="t5" class="form-control" placeholder="Create Your Password *" required>
                    </div>
                    <div class="col-md-6">
                      <label><strong>Confirm Password</strong></label>
                      <input type="text" name="t6" class="form-control" placeholder="Create Your Password *" required>
                    </div>
                    <div class="col-md-12" align="right" style="padding-top:20px">
                      <input type="submit" class="btn btn-danger" value="Register" name="send">
                    </div>
                  </div>
                </form>
              </div>
              <div class="card-footer">
                <h6 align="center">Already Register? <a href="#" data-bs-toggle="modal" data-bs-target="#myModal">Login</a></h6>
              </div>
            </div>  
        </div>
      </div>
      <?php
    

  ?>