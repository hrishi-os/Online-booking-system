<?php
session_start();
  include "dbcon.php";
  if(isset($_POST['ulogin']))
  {
    $a=$_POST['t1'];
    $b=$_POST['t2'];
    $se=mysqli_query($con,"select *from users where email='$a'");
    $se1=mysqli_fetch_assoc($se);
    $ps=$se1['password'];
    if($b==$ps)
    {
      $_SESSION['ulog']=$a;
      $_SESSION['name']=$se1['name'];
      header("location:User/index.php");
    }
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Ticket Booking System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
</head>
<body class="container-fluid">
<div class="row">
  <div class="col-md-12 px-0">
    <nav class="navbar navbar-expand-sm bg-info navbar-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"><img src="img/logo.png"></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link text-dark" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-dark" href="register.php">Registration</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-dark" href="#" data-bs-toggle="modal" data-bs-target="#myModal">Login</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-dark" href="admin-login.html">Admin Login</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
  </div>
</div>







<!-- The Modal -->
<div class="modal fade" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Login Here</h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form method="post">
          <p><strong>Username</strong></p>
          <input type="text" name="t1" class="form-control" required placeholder="Username *">
          <p><strong>Password</strong></p>
          <input type="password" name="t2" class="form-control" required placeholder="********">
          <p style="padding-top: 10px;" class="d-grid">
            <input type="submit" name="ulogin" value="Login" class="btn btn-info">
          </p>
        </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>

<script type="text/javascript">
  $(function(){
    var dtToday = new Date();

    var month = dtToday.getMonth() + 1;
    var day = dtToday.getDate();
    var year = dtToday.getFullYear();
    if(month < 10)
        month = '0' + month.toString();
    if(day < 10)
        day = '0' + day.toString();

    var minDate= year + '-' + month + '-' + day;

    $('#txtDate').attr('min', minDate);
});

  $(function(){
    var dtToday = new Date();

    var month = dtToday.getMonth() + 1;
    var day = dtToday.getDate();
    var year = dtToday.getFullYear();
    if(month < 10)
        month = '0' + month.toString();
    if(day < 10)
        day = '0' + day.toString();

    var minDate= year + '-' + month + '-' + day;

    $('#txtDate1').attr('min', minDate);
});

  $(function(){
    var dtToday = new Date();

    var month = dtToday.getMonth() + 1;
    var day = dtToday.getDate();
    var year = dtToday.getFullYear();
    if(month < 10)
        month = '0' + month.toString();
    if(day < 10)
        day = '0' + day.toString();

    var minDate= year + '-' + month + '-' + day;

    $('#txtDate2').attr('min', minDate);
});
</script>