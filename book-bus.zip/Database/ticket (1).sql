-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 20, 2023 at 03:07 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ticket`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `username`, `password`) VALUES
(1, 'Administration', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `id` int(11) NOT NULL,
  `fareid` varchar(30) NOT NULL,
  `uid` varchar(30) NOT NULL,
  `quantity` varchar(30) NOT NULL,
  `jdate` varchar(40) NOT NULL,
  `dob` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`id`, `fareid`, `uid`, `quantity`, `jdate`, `dob`, `status`) VALUES
(1, '4', 'spwebcare@gmail.com', '1', '2023-05-25', '2023-05-19 08:20:57', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `booking_bus`
--

CREATE TABLE `booking_bus` (
  `id` int(11) NOT NULL,
  `bfid` varchar(30) NOT NULL,
  `uid` varchar(30) NOT NULL,
  `quantity` varchar(30) NOT NULL,
  `jdate` varchar(30) NOT NULL,
  `dob` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `booking_bus`
--

INSERT INTO `booking_bus` (`id`, `bfid`, `uid`, `quantity`, `jdate`, `dob`, `status`) VALUES
(1, '1', 'spwebcare@gmail.com', '1', '2023-05-26', '2023-05-20 08:24:10', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `booking_train`
--

CREATE TABLE `booking_train` (
  `id` int(11) NOT NULL,
  `trainid` varchar(30) NOT NULL,
  `uid` varchar(30) NOT NULL,
  `quantity` varchar(30) NOT NULL,
  `jdate` varchar(30) NOT NULL,
  `dob` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `booking_train`
--

INSERT INTO `booking_train` (`id`, `trainid`, `uid`, `quantity`, `jdate`, `dob`, `status`) VALUES
(1, '2', 'spwebcare@gmail.com', '1', '2023-05-25', '2023-05-20 02:40:08', 'Confirm');

-- --------------------------------------------------------

--
-- Table structure for table `bus_fare`
--

CREATE TABLE `bus_fare` (
  `id` int(11) NOT NULL,
  `busname` varchar(30) NOT NULL,
  `source` varchar(30) NOT NULL,
  `destination` varchar(30) NOT NULL,
  `cl` varchar(30) NOT NULL,
  `fare` varchar(30) NOT NULL,
  `doe` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bus_fare`
--

INSERT INTO `bus_fare` (`id`, `busname`, `source`, `destination`, `cl`, `fare`, `doe`) VALUES
(1, 'Red Bus', 'Ranchi', 'Jamshedpur', 'Normal', '250', '2023-05-20 07:31:47'),
(2, 'Satyam Bus Agency', 'Ranchi', 'Patna', 'Normal', '420', '2023-05-20 07:32:28'),
(3, 'Sheela Bus', 'Ranchi', 'Jamshedpur', 'Normal', '240', '2023-05-20 07:32:41');

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE `city` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `doe` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`id`, `name`, `doe`) VALUES
(5, 'Ranchi', '2023-05-11 01:51:42'),
(6, 'Kolkatta', '2023-05-11 01:51:59'),
(7, 'Patna', '2023-05-20 07:22:51'),
(8, 'Jamshedpur', '2023-05-20 07:23:00');

-- --------------------------------------------------------

--
-- Table structure for table `fare`
--

CREATE TABLE `fare` (
  `id` int(11) NOT NULL,
  `source` varchar(30) NOT NULL,
  `destination` varchar(30) NOT NULL,
  `cl` varchar(50) NOT NULL,
  `fare` varchar(30) NOT NULL,
  `doe` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fare`
--

INSERT INTO `fare` (`id`, `source`, `destination`, `cl`, `fare`, `doe`) VALUES
(3, 'Ranchi', 'Kolkatta', 'Economy', '2350', '2023-05-11 01:58:00'),
(4, 'Ranchi', 'Kolkatta', 'Business Class', '4600', '2023-05-11 01:58:11'),
(5, 'Ranchi', 'Kolkatta', 'First Class', '6100', '2023-05-11 01:58:22'),
(6, 'Ranchi', 'Kolkatta', 'Premium Economy', '8200', '2023-05-11 01:58:32');

-- --------------------------------------------------------

--
-- Table structure for table `station`
--

CREATE TABLE `station` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `doa` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `station`
--

INSERT INTO `station` (`id`, `name`, `doa`) VALUES
(2, 'Tata', '2023-05-18 16:08:43'),
(3, 'Ranchi', '2023-05-18 16:08:49');

-- --------------------------------------------------------

--
-- Table structure for table `train`
--

CREATE TABLE `train` (
  `id` int(11) NOT NULL,
  `source` varchar(30) NOT NULL,
  `destination` varchar(30) NOT NULL,
  `trainno` varchar(30) NOT NULL,
  `timing` varchar(100) NOT NULL,
  `cl` varchar(100) NOT NULL,
  `fare` varchar(30) NOT NULL,
  `doe` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `train`
--

INSERT INTO `train` (`id`, `source`, `destination`, `trainno`, `timing`, `cl`, `fare`, `doe`) VALUES
(2, 'Tata', 'Ranchi', '45612', '9:20am-9:30am', 'General', '135', '2023-05-18 16:05:56');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `password` varchar(100) NOT NULL,
  `dor` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `mobile`, `gender`, `password`, `dor`) VALUES
(1, 'Shyam Sundar Pradhan', 'spwebcare@gmail.com', '6207408069', 'Male', '12345', '2023-05-18 13:28:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `booking_bus`
--
ALTER TABLE `booking_bus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `booking_train`
--
ALTER TABLE `booking_train`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bus_fare`
--
ALTER TABLE `bus_fare`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fare`
--
ALTER TABLE `fare`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `station`
--
ALTER TABLE `station`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `train`
--
ALTER TABLE `train`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `booking_bus`
--
ALTER TABLE `booking_bus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `booking_train`
--
ALTER TABLE `booking_train`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `bus_fare`
--
ALTER TABLE `bus_fare`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `fare`
--
ALTER TABLE `fare`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `station`
--
ALTER TABLE `station`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `train`
--
ALTER TABLE `train`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
