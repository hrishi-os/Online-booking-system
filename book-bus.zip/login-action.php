<?php
session_start();
include "dbcon.php";
$a=$_POST['t1'];
$b=$_POST['t2'];

$se=mysqli_query($con,"select *from admin where username='$a'");
$row=mysqli_num_rows($se);
if($row>0)
{
	$se1=mysqli_fetch_assoc($se);
	$ps=$se1['password'];
	if($ps==$b)
	{
		$_SESSION['name']=$se1['name'];
		$_SESSION['alog']=$a;
		header("location:Admin/index.php");
	}
	else
	{
		echo "<script>alert('Password mismatch, please try again');</script>";
		echo "<script>window.location='admin-login.html';</script>";
	}
}
else
{
	echo "<script>alert('Sorry! You do not have any account.');</script>";
	echo "<script>window.location='admin-login.html';</script>";
}
?>