<?php

include "header.php";

  if(isset($_SESSION['ulog'])) 
  { 
  	$a=$_REQUEST['t1'];//fare id
  	$b=$_REQUEST['t2'];// user id
  	$c=$_REQUEST['t3'];// quantity
    $d=$_REQUEST['date'];

  	$fa=mysqli_query($con,"select *from bus_fare where id=$a");
  	$fa1=mysqli_fetch_assoc($fa);
  	$ud=mysqli_query($con,"select *from users where email='$b'");
  	$ud1=mysqli_fetch_assoc($ud);


  	$in=mysqli_query($con,"insert into booking_bus(bfid,uid,quantity,jdate,status) values('$a','$b','$c','$d','Pending')");

  	?>
  	<div class="row">
  		<div class="col-md-6 offset-md-3" style="padding: 30px 0px 30px 0px;">
  		<div class="card" id="pr">
  		<div class="card-header">
  			<h3>Booking Details</h3>
  		</div>
  		<div class="card-body">
  			<table class="table table-bodered">
  				<tr>
  					<th colspan="2"><h4>User Details</h4></th>
  				</tr>
  				<tr>
  					<td>Name</td>
  					<td><?php echo $ud1['name']; ?></td>
  				</tr>
  				<tr>
  					<td>Email ID</td>
  					<td><?php echo $ud1['email']; ?></td>
  				</tr>
  				<tr>
  					<td>Mobile No.</td>
  					<td><?php echo $ud1['mobile']; ?></td>
  				</tr>
  				<tr>
  					<th colspan="2"><h4>Booking Details</h4></th>
  				</tr>
          <tr>
            <td>Date</td>
            <td><?php echo $d; ?></td>
          </tr>
  				<tr>
  					<td>Location</td>
  					<td><?php echo $fa1['source']; ?> To <?php echo $fa1['destination']; ?></td>
  				</tr>
  				<tr>
  					<td>Class</td>
  					<td><?php echo $fa1['cl']; ?></td>
  				</tr>
  				<tr>
  					<td>Fare Per Person</td>
  					<td><?php echo $fa1['fare']; ?>/-</td>
  				</tr>
  				<tr>
  					<th colspan="2"><h4>Payment Details</h4></th>
  				</tr>
  				<tr>
  					<td>No of Person</td>
  					<td><?php echo $c; ?></td>
  				</tr>
  				<tr>
  					<td>Total Amount</td>
  					<td><?php echo $tm=$fa1['fare']*$c; ?>/-</td>
  				</tr>
  				<tr>
  					<td>Taxes (18%) GST</td>
  					<td><?php echo $tax=round($tm*18/100); ?>/-</td>
  				</tr>
  				<tr>
  					<td>Amount Payble</td>
  					<td><?php echo $tm+$tax; ?>/-</td>
  				</tr>
  				<tr align="center">
  					<th><button class="btn btn-info btn-block" onclick="print()">Print</button></th>
  					<th><a href="https://checkout.stripe.com/c/pay/" class="btn btn-success btn-block">Proceed to Payment</a></th>
  				</tr>
  			</table>
  		</div>
  		</div>
  		</div>
  	</div>
  	<?php
  }
?>