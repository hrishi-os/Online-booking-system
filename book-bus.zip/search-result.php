<?php
  

    include "header.php";

    
  if(isset($_POST['flight']))
    {
      $a=$_POST['t1'];
      $b=$_POST['t2'];
      $c=$_POST['t3'];
      $d=$_POST['t4'];

      $se=mysqli_query($con,"select *from fare where source='$a' AND destination='$b'");
      $row=mysqli_num_rows($se);
      if($row>0)
      {
      ?>
      <div class="row" style="padding-top:30px">
        <div class="col-md-12" align="center">
          <h2>Search Results</h2><hr>
          <table class="table table-hover">
            <tr>
              <th>Source</th>
              <th>Destination</th>
              <th>Class</th>
              <th>Fare (WIthout Taxes)</th>
              <th>Action</th>
            </tr>
            <?php while($se1=mysqli_fetch_assoc($se))
            {
              ?>
              <tr>
                <td><?php echo $se1['source']; ?></td>
                <td><?php echo $se1['destination']; ?></td>
                <td><?php echo $se1['cl']; ?></td>
                <td>Rs. <?php echo $se1['fare']; ?>/-</td>
                <td><a href="book.php?id=<?php echo $se1['id']; ?>" class="btn btn-success">Book Now</a></td>
              </tr>
              <?php
            }?>
          </table>
        </div>
      </div>
      <?php
    }
    else
    {
      ?>
      <h1>&nbsp;</h1>
      <h1 style="font-size:150px;text-align: center;">Not found....!</h1>
      <?php
    }
    }




    if(isset($_POST['train']))
    {
      $a=$_POST['t1'];
      $b=$_POST['t2'];
      $c=$_POST['t3'];
      $d=$_POST['t4'];

      $se=mysqli_query($con,"select *from train where source='$a' AND destination='$b'");
      $row=mysqli_num_rows($se);
      if($row>0)
      {
      ?>
      <div class="row" style="padding-top:30px">
        <div class="col-md-12" align="center">
          <h2>Search Results</h2><hr>
          <table class="table table-hover">
            <tr>
              <th>Source</th>
              <th>Destination</th>
              <th>Train No.</th>
              <th>Timing</th>
              <th>Class</th>
              <th>Fare (WIthout Taxes)</th>
              <th>Action</th>
            </tr>
            <?php while($se1=mysqli_fetch_assoc($se))
            {
              ?>
              <tr>
                <td><?php echo $se1['source']; ?></td>
                <td><?php echo $se1['destination']; ?></td>
                <td><?php echo $se1['trainno']; ?></td>
                <td><?php echo $se1['timing']; ?></td>
                <td><?php echo $se1['cl']; ?></td>
                <td>Rs. <?php echo $se1['fare']; ?>/-</td>
                <td><a href="book-train.php?id=<?php echo $se1['id']; ?>" class="btn btn-success">Book Now</a></td>
              </tr>
              <?php
            }?>
          </table>
        </div>
      </div>
      <?php
    }
    else
    {
      ?>
      <h1>&nbsp;</h1>
      <h1 style="font-size:150px;text-align: center;">Not found....!</h1>
      <?php
    }
    }


    if(isset($_POST['bus']))
    {
      $a=$_POST['t1'];
      $b=$_POST['t2'];
      $d=$_POST['t4'];

      $se=mysqli_query($con,"select *from bus_fare where source='$a' AND destination='$b'");
      $row=mysqli_num_rows($se);
      if($row>0)
      {
      ?>
      <div class="row" style="padding-top:30px">
        <div class="col-md-12" align="center">
          <h2>Search Results</h2><hr>
          <table class="table table-hover">
            <tr>
              <th>Bus Name</th>
              <th>Source</th>
              <th>Destination</th>
              <th>Class</th>
              <th>Fare (WIthout Taxes)</th>
              <th>Action</th>
            </tr>
            <?php while($se1=mysqli_fetch_assoc($se))
            {
              ?>
              <tr>
                <td><?php echo $se1['busname']; ?></td>
                <td><?php echo $se1['source']; ?></td>
                <td><?php echo $se1['destination']; ?></td>
                <td><?php echo $se1['cl']; ?></td>
                <td>Rs. <?php echo $se1['fare']; ?>/-</td>
                <td><a href="book-bus.php?id=<?php echo $se1['id']; ?>" class="btn btn-success">Book Now</a></td>
              </tr>
              <?php
            }?>
          </table>
        </div>
      </div>
      <?php
    }
    else
    {
      ?>
      <h1>&nbsp;</h1>
      <h1 style="font-size:150px;text-align: center;">Not found....!</h1>
      <?php
    }
    }
  ?>