<?php
  

    include "header.php";

  if(isset($_SESSION['ulog'])) 
  { 
  if(isset($_GET['id']))
    {
      $a=$_GET['id'];

      $se=mysqli_query($con,"select *from train where id=$a");
      $se1=mysqli_fetch_assoc($se)
      
      ?>
      <script type="text/javascript">
        function myfun()
        {
          let pr=document.getElementById("person").value;
          let fr=<?php echo $se1['fare']; ?>;
          let tm=pr*fr;
          document.getElementById("per").innerHTML=tm;
          let ta=Math.round((tm*18)/100);
          document.getElementById("tax").innerHTML=ta;
          let ap=tm+ta;
          document.getElementById("ap").innerHTML=ap;
          
        }
      </script>
      <div class="row" style="padding-top:30px">
        <div class="col-md-8 offset-md-2" align="center">
          <h2>Booking Details</h2><hr>
          <form method="post" action="booking-action1.php">
          <table class="table table-hover table-bordered">
            <input type="hidden" name="t1" value="<?php echo $a; ?>">
            <input type="hidden" name="t2" value="<?php echo $_SESSION['ulog']; ?>">
            <tr>
              <th>Train No.</th>
              <td><?php echo $se1['trainno']; ?></td>
              <th>Timing</th>
              <td><?php echo $se1['timing']; ?></td>
            </tr>
            <tr>
              <th>Source</th>
              <td><?php echo $se1['source']; ?></td>
              <th>Date</th>
              <td><input type="text" name="date" class="form-control" placeholder="Select Date" required onfocus="type='date'" id="txtDate"></td>
            </tr>
            <tr>
              <th>Destination</th>
              <td><?php echo $se1['destination']; ?></td>
              <th>No. of Person</th>
              <td><input type="number" value="1" class="form-control" id="person" name="t3" onchange="myfun()" min="1"></td>
              
            </tr>
            <tr>
              <th>Class</th>
              <td><?php echo $se1['cl']; ?></td>
              <th>Total Amount</th>
              <td align="right"><span id="per"><?php echo $fr=$se1['fare']; ?></span></td>
            <tr>
              <th>Fare (Without Taxes)</th>
              <td><?php echo $fr=$se1['fare']; ?></td>
              <th>GST (18%)</th>
              <td align="right"><span id="tax"><?php echo $am=round(($se1['fare']*18)/100); ?></span></td>
              
            </tr>
            <tr>
              <td colspan="2"></td>
              <th>Total Payble</th>
              <td align="right"><span id="ap"><?php echo $am+$fr; ?></span></td>
            </tr>
            <tr>
              <td colspan="4" align="right"><input type="submit" value="Confirm" class="btn btn-warning"></td>
            </tr>
          </table>
        </form>
        </div>
      </div>
      <?php
    
    }
  }
  else
  {
    echo "<script>alert('Please Login');</script>";
  }

  ?>